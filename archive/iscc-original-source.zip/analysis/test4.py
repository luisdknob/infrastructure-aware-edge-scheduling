import json
import bitmath
import pandas as pd
import matplotlib.pyplot as pyplot

files = ["scenario-1-ipe-top-50-apps-kube-scheduler-network_log_1622215549", "scenario-2-ipe-top-50-apps-kube-scheduler-image-locality-network_log_1622215867",
        "scenario-4-ipe-top-50-apps-kube-scheduler-layer-locality-network_log_1622350539", "scenario-3-ipe-top-50-apps-kube-scheduler-infra-aware-network_log_1622350423"]

columns = ["Kube Scheduler","Image Locality","Layer Locality","Infrastructure Aware"]

df = pd.DataFrame()
#newFrame2 = pd.DataFrame()

for id, file in enumerate(files):

    json_file =  open(file+".json", "r")

    load = json.load(json_file)

    nodes = load["graph"]["nodes"]

    values = []

    for node in filter(lambda x: x["type"] == "chost", nodes):
        #print(node["name"])
        disk_occupation = bitmath.Byte(0)
        for layer in node["layers"]:
            disk_occupation += bitmath.parse_string(layer[1])
        #print(disk_occupation.best_prefix(system=bitmath.SI))
        values.append(dict(name=node["name"], size=float(disk_occupation.to_MB())))
        #if node["name"] == "edge2":
            #print(dict(name=node["name"], size=float(disk_occupation.to_MB())))


    df2 = pd.DataFrame().from_dict(values)
    df2.rename(columns={'size': columns[id]}, inplace=True)
    if id == 0:
        df2.set_index(["name"], inplace=True)
        df = df2
    else:
        df = df.merge(df2, how='left', on='name')

# plt = df.boxplot(fontsize=16, figsize=(12,8))
# #print(df.sum())
# # print(df.mean())
# plt.set_xlabel("scheduler", fontsize=14)
# plt.set_ylabel("storage (MB)", fontsize=14)
# #plt.set_title("Node storage usage by scheduler", fontsize=20)
# pyplot.savefig("storage_usage.png", transparent=True)

print(df.mean())
print(df.min())
print(df.max())