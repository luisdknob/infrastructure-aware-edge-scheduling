# %% 
import pandas as pd
import json
import matplotlib.pyplot as pyplot
from pandas.core.frame import DataFrame

chostsNum = 168

color = ["blue", "red", "green", "grey"]

columns = ["Kube Scheduler","Image Locality","Layer Locality","Infrastructure Aware"]

files = ["scenario-1-ipe-top-50-apps-kube-scheduler-cache_status_1622215549", "scenario-2-ipe-top-50-apps-kube-scheduler-image-locality-cache_status_1622215867",
        "scenario-4-ipe-top-50-apps-kube-scheduler-layer-locality-cache_status_1622350539", "scenario-3-ipe-top-50-apps-kube-scheduler-infra-aware-cache_status_1622350423"]
        
newFrame = DataFrame()
newFrame2 = DataFrame()

for id, file in enumerate(files):

    csv_file =  open(file+".csv", "r")

    df = pd.read_csv(csv_file, delimiter=";")

    a = df.sum()
    d = df["total"].to_list()
    print(len(list(filter(lambda x: x > 0, d))))
    #b = df["total"].mean()
    #c = df["total"].std(ddof=0)

    newFrame[columns[id]] = df["total"]
    newFrame2[columns[id]] = df["miss"]

    print(a["hit"],a["miss"])

#plt = newFrame.boxplot()
#plt.legend(["Kube Scheduler","Image Locality","Layer Locality","Least Congested Node"])
#pyplot.show()

#plt = newFrame2.boxplot()
#plt.legend(["Kube Scheduler","Image Locality","Layer Locality","Least Congested Node"])
#pyplot.show()