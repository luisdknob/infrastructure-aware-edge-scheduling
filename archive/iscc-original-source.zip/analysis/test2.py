# %% 
import pandas as pd
import json
import matplotlib.pyplot as pyplot
from matplotlib.lines import Line2D

cache = "1"

color = ["blue", "red", "green", "grey"]

files = ["scenario-1-ipe-top-50-apps-kube-scheduler-provision_time_1622215549", "scenario-2-ipe-top-50-apps-kube-scheduler-image-locality-provision_time_1622215867",
        "scenario-4-ipe-top-50-apps-kube-scheduler-layer-locality-provision_time_1622350539", "scenario-3-ipe-top-50-apps-kube-scheduler-infra-aware-provision_time_1622350423"]

for id, file in enumerate(files):

    json_file =  open(file+".csv", "r")

    #load = json.load(json_file)

    df = pd.read_csv(json_file, delimiter=";")

# %%

    #print(df)

    # # b = df.groupby(['host']).count()

    # print(file)
    # # print(b["name"].std())
    # # print(b["name"].min())
    # # print(b["name"].max())

    # print(df["provision_time"].quantile(q=0.99))
    # print(df["provision_time"].mean())
    # print(df["provision_time"].max())




# %%
 
    #df["percentage"] = df["percentage"].clip(lower=0)


     # Frequency
    stats_df = df \
    .groupby('provision_time') \
    ['provision_time'] \
    .agg('count') \
    .pipe(pd.DataFrame) \
    .rename(columns = {'provision_time': 'frequency'})

    #PDF
    stats_df['pdf'] = stats_df['frequency'] / sum(stats_df['frequency'])

    #CDF
    stats_df['cdf'] = stats_df['pdf'].cumsum()
    stats_df = stats_df.reset_index()

    print(stats_df)
# #stats_df.head(505)

# %%

    grid = True if id == 0 else False

    plt = stats_df.plot(y = 'cdf', x = 'provision_time', grid = grid, figsize=(12,8), color=color[id], lw=2, fontsize=16)
    plt.set_ylim(0.0,1.0)
    plt.set_xlim(0,275)
    plt.set_yticks([0.0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0])
    plt.set_xticks([0,25,50,75,100,125,150,175,200,225,250,275])
    if grid:
        plt.set_ylabel("percentage of applications (cdf)", fontsize=14)
        plt.set_xlabel("provision time (s)", fontsize=14)
        #plt.set_title("Provision time by priority", fontsize=20)
    else:
        plt.axis("off")

    if id == 0:
        legend_elements = [Line2D([0], [0], color='blue', lw=3, label='Line'),
        Line2D([0], [0], color='red', lw=3, label='Line'),
        Line2D([0], [0], color='green', lw=3, label='Line'),
        Line2D([0], [0], color='grey', lw=3, label='Line')
                    ]
        plt.legend(legend_elements, ["Kube Scheduler","Image Locality","Layer Locality","Infrastructure Aware"], loc='lower right')
        pyplot.savefig("cdf_"+cache+"_grid.png", transparent=True)
    else:
        plt.legend().set_visible(False)    
        pyplot.savefig("cdf_"+cache+"_"+str(id)+".png", transparent=True)
# %%
